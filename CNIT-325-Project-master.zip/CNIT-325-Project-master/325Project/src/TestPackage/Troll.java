/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestPackage;

/**
 *
 * @author trevor
 */

//class construtor assigning varible values
public class Troll extends Enemy {
    
    Troll() {
        enemyMax = 100;
        enemyAtt = 15;
        enemyDef = 25;
        enemyName = "Troll";
    }
    
}
