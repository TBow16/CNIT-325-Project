/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestPackage;

/**
 *
 * @author trevor
 */
public class Boss extends Enemy {
    
    //class construtor assigning varible values
    Boss() {
        enemyMax = 500;
        enemyAtt = 25;
        enemyDef = 25;
        enemyName = "Dragon";
    }
    
}
