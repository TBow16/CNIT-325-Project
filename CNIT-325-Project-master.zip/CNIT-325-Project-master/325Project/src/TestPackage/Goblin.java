/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestPackage;

/**
 *
 * @author trevor
 */

//class construtor assigning varible values
public class Goblin extends Enemy {
    
    Goblin() {
        enemyMax = 50;
        enemyAtt = 20;
        enemyDef = 20;
        enemyName = "Goblin";
    }
    
}
